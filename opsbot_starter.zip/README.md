# OpsBot
A minimal full-stack support bot using GPT-4, FastAPI, and React, optimized for Codespaces.